Hi There,
Thank you for downloading my font!

This font is for PERSONAL USE ONLY !( NOT FOR COMMERCIAL )

If you want all version and to use this font for COMMERCIAL, You need a commercial license that can be purchased in my shop :
https://hakaratype.gumroad.com

Or you can provide support to me by making a donation.
Paypal account for donation: https://paypal.me/Adiklau

Thank you, please support each other :)

Don't hesitate to contact me if you have any problem
you can sent an email to kanisadizero@gmail.com

Thanks,
Hakara Type